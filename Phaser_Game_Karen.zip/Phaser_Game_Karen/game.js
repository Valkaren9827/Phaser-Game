window.onload = function() {
    var tileSize = 80;
    var numRows = 4;
    var numCols = 5;
    var tileSpacing = 10;
    var tileArray = [];
    var selectedArray = [];
    //ÉTAPE 4 : il est très important de commencer avec un écran de titre en sourdine où le joueur peut clairement choisir de 
    //jouer avec des sons ou non. Nous devrons donc d'abord créer une nouvelle variable appelée playSound. Ici, nous allons stocker la décision du joueur.
    var playSound = {};
    //
    var game = new Phaser.Game(500, 500);

    var playGame = function(game){}

    playGame.prototype = {
        //ÉTAPE 12 : L'idée qu'on veut ici c'est de stocker tout les sons dans un tableau, et puis de faire jouer la bonne chanson en fonction de ce qui se passe
        // dans le jeu. On va aller dans une propriété dans l'objet playGame pi on va l'appeller soundArray. C'est défini comme un tableau vide ca va être visible
        //seulement dans l'objet playGame, on le déclare comme ceci :
        soundArray: [],
        //
        preload : function() {
            game.load.spritesheet("tile", "/assets/sprites/tuiles.png", tileSize, tileSize);
            //ÉTAPE 11 si pas assez de temps : 
        //Nous allons pré chargé nos sons, c'est pas mal la même chose que quand on charge nos images, alors on retourne vers l'objet
        //playGame :
        //load.audio(key, audioPHiles) gère le préchargement du son. Le premier argument est la clé, le second est un tableau de fichiers à charger, dans différents formats.
            game.load.audio("select", ["/assets/sons/select.mp3", "select.ogg"]);
            game.load.audio("right", ["/assets/sons/right.mp3", "right.ogg"]);
            game.load.audio("wrong", ["/assets/sons/wrong.mp3", "wrong.ogg"]);
        //Phaser va pouvoir choisir le format du sons à jouer en fonction des capacités de notre navigateur.
        }, 
        create : function() {
            console.log("Ça c'est mon jeu de mémoire cool!")
        },
        create : function(){
            game.add.image(0, 0, "tile");
        },
        create : function() {
            this.placeTile();
        // ÉTAPE 13 : Dans le même objet playGame, à l'intérieur de la méthode create, une fois qu'on a appelé placeTile et qu'on a ajouté l'audio dans le pré chargement,
        //si le joueur à sélectionné l'option de jouer avec du son, on veut définir notre playSound à true.
            if(playSound) {
                this.soundArray[0] = game.add.audio("select", 1);
                this.soundArray[1] = game.add.audio("right", 1);
                this.soundArray[2] = game.add.audio("wrong", 1);
            }
        // Pour inséré des éléments dans un tableau on aurait pu tout simplement utilisé la méthode push, mais je me suis dit que c'était simple comme ça,
        //,déclarer les éléments un par un en attribuant une valeur à un index, jugez moi pas.
        },
        placeTile: function() {
            var leftSpace = (game.width - (numCols * tileSize) - ((numCols - 1) * tileSpacing))/2;
            var topSpace = (game.height - (numRows * tileSize) - ((numRows - 1) * tileSpacing))/2;
            for(var i = 0; i < numRows * numCols; i++){
                tileArray.push(Math.floor(i / 2));
            }
            console.log("les valeurs de mes tuiles: " + tileArray);

            //ÉTAPE 3 :
            // Ici on vient augmenter la difficulté du jeu en déplancant les tuiles dans d'autres rangés avec un LOOP.
            // A chaque itération, deux éléments choisis au hasard dans le tableau tilesArray sont échangés, à l'aide d'une variable temporaire.

            for(i = 0; i < numRows * numCols; i++) {
                var from = game.rnd.between(0, tileArray.length-1); //rnd.between(min, max) génère un nombre entier aléatoire allant de min à max , tous deux inclus.
                var to = game.rnd.between(0, tileArray.length-1);
                var temp = tileArray[from];

                tileArray[from] = tileArray[to];
                tileArray[to] = temp;
            }
            //Et cette dernière fonctionnalité complète notre jeu, un jeu sympa auquel personne ne voudra jouer. Bien que le jeu fonctionne et fonctionne bien,
            //vous ne pouvez pas croire que les gens joueront à des jeux sans thème,
            //sans objectif, sans aucune torsion. Dans les années 1970, les joueurs auraient probablement adoré votre jeu, mais aujourd'hui, ils ne le feront pas.

            //

            for (var i = 0; i < numCols; i++) {
                for (var j = 0; j < numRows; j++) {
                    var tile = game.add.button( i * (tileSize + tileSpacing), j * (tileSize + tileSpacing), "tile", this.showTile, this);
                    tile.frame = 11;
                    tile.value = tileArray[j * numCols + i];
                }
            }
        }, 
        showTile: function(target) {
            if(selectedArray.length < 2 && selectedArray.indexOf(target) == -1) {
                //ÉTAPE 14 : Maintenant que les sons sont pré chargés et prêts à être joués, il est temps d'insérer notre premier son dans la méthode showTile. 
                //Il va être joué quand une tuile va être affichée.
                if(playSound) {
                    this.soundArray[0].play();
                }
                //Évidemment, avant de jouer un effet sonore, on doit vérifier que playSound est vrai.
                //
                target.frame = target.value;
                selectedArray.push(target);

                if(selectedArray.length == 2){
                    game.time.events.add(Phaser.Timer.SECOND, this.checkTiles, this);
                    //ÉTAPE 1 
                    // Donnez un temps de réflexion au jeu.
                }
            }
        },
        checkTiles: function() {
            //ÉTAPE 2: 

            //Une fois que nous avons sélectionné deux tuiles, 
            //alors selectedArray a deux éléments, et nous devons vérifier leurs valeurs. 
            //Nous supprimerons les tuiles si les valeurs correspondent, ou les recouvrirons à nouveau si les valeurs ne correspondent pas. 
            //Cela signifie que quelques lignes supplémentaires ont été ajoutées à la fonction showTile :
            // C'est ainsi que nous vérifions que le tableau sélectionné a deux éléments, 
            //il est donc temps de vérifier que les tuiles ont la même valeur :
            if(selectedArray[0].value == selectedArray[1].value) { 
                //Nous accédons à la propriété personnalisée value des premier et deuxième éléments de tableau sélectionnés et vérifions qu'ils sont égaux. 
                //S'ils sont égaux, il est temps de retirer les tuiles de la scène.
               selectedArray[0].destroy(); 
               
               //destroy détruit définitivement le bouton, détruit l'événement d'entrée et les gestionnaires d'animation s'ils sont présents et annule sa référence au jeu,
               // le libérant.
               selectedArray[1].destroy(); //Et maintenant, nous avons terminé lorsque le joueur a sélectionné des tuiles avec les mêmes symboles.

               } else { //Nous devons utiliser une extension à l'instruction if appelée else.
                        //Nous modifions simplement les propriétés du cadre des deux tuiles pour les réactiver. Enfin, peu importe si les tuiles ont été supprimées 
                        //ou recouvertes, nous devons vider le tableau selectedArray pour permettre au joueur de sélectionner un nouveau couple de tuiles.
              selectedArray[0].frame = 11;
              selectedArray[1].frame = 11;
        
              selectedArray.length = 0; //To empty an array, we set its length to zero:
             }
        }
    }

    //ÉTAPE 6 : On ajoute le nouveau code ici : De la même façon qu'on a utiliser l'objet playGame avec un preaload et create, maintenant on fait la 
    //même chose avec titleScreen :

    var titleScreen = function(game) {}
 
    titleScreen.prototype = {
        
        preload: function() {
            game.load.spritesheet("soundicons", "/assets/sprites/soundicons.png", 80, 80);
            //ÉTAPE 7 :
            //Ici j'ai préchargé mes icones de son, il y en a un qui est pour muter et l'autre pour rester le son actif
            //J'ai fait 80,80 pour les centré pour le titre.
        },
     
        create: function() {
            // ÉTAPE 8 : On ajoute ici le style de notre page titre de notre jeu : le style de text avec la grosseur, la couleur et l'alignement.
            var style = {
                font: "48px Monospace",
                fill: "red",
                align: "center"
            };
            // ÉTAPE 9 : Des boutons sonores sont ensuite ajoutés à la scène, à l'intérieur de la fonction de création :
            //C'est le code standard utilisé pour créer un bouton. Jetez un coup d'œil à la fonction de rappel - startGame - et à un nouveau concept appelé point d'ancrage.
            var text = game.add.text(game.width / 2, game.height / 2 - 100, "Hack si tu peux", style);
            text.anchor.set(0.5);
        //L'ancre définit le point d'origine de la texture. La valeur par défaut est 0, 0 cela signifie que l'origine de la texture est en haut à gauche. Mettre l'ancre à 0.5, 0.5
        //signifie que l'origine des textures est centrée. Définir l'ancre sur 1,1 signifierait que les points d'origine
        // des textures seront le coin inférieur droit. Deux valeurs égales ne peuvent être écrites qu'une seule fois. anchor.set(0.5, 0.5) peut être écrit comme anchor.set(0.5).
            var soundButton = game.add.button(
                game.width / 2 - 100 , game.height / 2 + 100, "soundicons", this.startGame, this
            );
        
            soundButton.anchor.set(0.5);
            soundButton = game.add.button(
                game.width / 2 + 100 , game.height / 2 + 100, "soundicons", this.startGame, this
            );
        
            soundButton.frame = 1;
            soundButton.anchor.set(0.5);
        //Dans ce cas, nous voulons que les boutons aient leurs points d'ancrage dans leur centre horizontal et vertical.
        // N'oubliez pas que l'image doit avoir une hauteur et une hauteur égales, sinon le résultat final sera un peu flou.
        },

        //ÉTAPE 10 : 
        //La première image - rappelez-vous, l'image zéro - représente l'icône "son activé", tandis que la deuxième image - l'image un - représente le bouton de sourdine.
        // En vérifiant le cadre du bouton sélectionné, nous pouvons définir playSound sur vrai ou faux.
        //Comme on le connait la variable booléenne.
        startGame: function(target) {
            if(target.frame == 0) {
                playSound = true;
            } else {
                playSound = false;
            }
            game.state.start("PlayGame");
        }
    }

    
    //ÉTAPE 5 : Cela aurait été beaucoup plus difficile si vous n'aviez pas appris à gérer les états.
    //Nous allons ajouter un nouvel état appelé TitleScreen qui pointe vers l'objet titleScreen et démarrer le jeu en le lançant plutôt que PlayGame.
    game.state.add("TitleScreen" , titleScreen);
    game.state.start("TitleScreen");
    game.state.add("PlayGame", playGame);

}